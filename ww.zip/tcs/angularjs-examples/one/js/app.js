'use strict'

angular.module('example',['ui.router']);

angular.module('example')
    .config(function ($stateProvider,$urlRouterProvider,$provide, $windowProvider) {

        $urlRouterProvider.otherwise('/setting');

        $stateProvider
            .state('setting',{
            url:'/setting',
            templateUrl:'template/setting.html'
            })
            .state('setting.profile',{
                url:'/profile',
                templateUrl:'template/profile.html'
            })
            .state('setting.account',{
                url:'/account',
                templateUrl:'template/account.html'
            })


        var $window = $windowProvider.$get();

        $provide.decorator('$log', function ($delegate){
            function appLogging(message, type) {
                $.ajax({
                    type: "POST",
                    url: "http://localhost:8081",
                    contentType: "application/json",
                    data: angular.toJson({
                        url: $window.location.href,
                        content: message,
                        type: type,
                        userAgent: $window.navigator.userAgent,
                        userLang: $window.navigator.language
                    })
                });
            }
            return {
                log: function(message) {
                    appLogging(message, "log");
                    return $delegate.log(message);
                },
                info: function(message) {
                    appLogging(message, "info");
                    return $delegate.info(message);
                },
                warn: function(message) {
                    appLogging(message, "warn");
                    return $delegate.warn(message);
                },
                error: function(message) {
                    if (message.stack) {
                        message = (message.message && message.stack.indexOf(message.message) === -1)
                            ? 'Error: ' + message.message + '\n' + message.stack
                            : message.stack;
                    } else if (message.sourceURL) {
                        message = message.message + '\n' + message.sourceURL + ':' + message.line;
                    }
                    appLogging(message, "angularError");
                    return $delegate.error(message);
                },
                debug: function(message) {
                    appLogging(message, "debug");
                    return $delegate.debug(message);
                }
            };
        });
    });

